a_file = open("PoemLine.txt")
lines_to_read = [16, 20]

for position, line in enumerate(a_file):
#Iterate over each line and its index
    if position in lines_to_read:
        print(line)